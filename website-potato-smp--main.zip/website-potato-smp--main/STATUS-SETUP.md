# Jumlah pemain dari Minecraft-MP

Satu-satunya sumber status dan jumlah pemain adalah [halaman Potato SMP di Minecraft-MP](https://minecraft-mp.com/server-s353692). Angka diambil dari tabel halaman tersebut. Tidak ada angka acak, tidak ada API key di website, dan gagal mengambil data tidak dianggap server offline.

## Pasang di GitHub Pages

1. Ekstrak ZIP lalu upload **isi folder website** ke root repository. Pastikan `index.html`, folder `assets`, folder `scripts`, dan folder `.github/workflows` ikut terupload. Folder `.github` kadang tersembunyi di pengelola file Android.
2. Di repository GitHub buka **Settings → Pages → Build and deployment → Source → GitHub Actions**.
3. Di tab **Actions**, buka **Potato SMP Pages + Player Status**, lalu pilih **Run workflow** pada branch utama. Jika Actions dinonaktifkan, aktifkan lebih dahulu.
4. Tunggu workflow hijau. Workflow menerbitkan website serta `status.json` dalam satu proses. File `CNAME` tetap disertakan; periksa domain sendiri di Settings → Pages.

Workflow berjalan saat kode diperbarui dan dijadwalkan sekitar setiap 5 menit. GitHub dapat menunda jadwal ketika sibuk. Jadwal hanya berjalan pada default branch repository; file workflow harus ada di sana. Website membaca hasil secara berkala dan menandai data lama setelah 10 menit. Ini status berkala dari Minecraft-MP, bukan hitungan detik langsung dari server.

Workflow tidak membuat commit setiap beberapa menit. Hasil `status.json` terbaru ada pada website yang diterbitkan; angka pada file repository tidak berubah otomatis. Pengaturan jadwal GitHub pada repository publik bisa dinonaktifkan setelah 60 hari tanpa aktivitas; jalankan/aktifkan kembali dari Actions jika perlu.

Jika halaman sumber gagal diakses atau formatnya berubah, hasil menjadi `unknown` dengan jumlah pemain kosong. Tombol ke sumber tetap tersedia. File snapshot awal dalam ZIP hanya hasil pemeriksaan saat pembuatan; aktifkan workflow agar terus diperbarui.

## Pilihan tambahan: Cloudflare Worker

Gunakan ini hanya jika ingin endpoint status terpisah, misalnya untuk hosting selain GitHub Pages. GitHub Actions di atas sudah cukup untuk pemasangan default.

1. Pasang Node.js dan Wrangler, lalu login ke akun Cloudflare sendiri.
2. Dari root proyek, jalankan:

   ```sh
   npx wrangler deploy --config integrations/worker/wrangler.toml
   ```

3. Simpan URL Worker yang diberikan, dengan akhiran `/status.json`, pada `statusUrl` di file `assets/config.js`. Contoh format: `https://potato-smp-status.namaakun.workers.dev/status.json`.

Worker memakai parser sumber yang sama, memperbolehkan pembacaan JSON lintas domain, dan menyimpan hasil selama 3 menit. Jika Minecraft-MP menolak permintaan, status tetap `unknown`; Worker tidak melewati proteksi situs. Worker belum diterbitkan dalam paket ini dan membutuhkan deployment pada akun sendiri.

## Verifikasi lokal

```sh
node --test scripts/status-source.test.mjs
node scripts/update-status.mjs
python -m http.server 8080
```

Lalu buka `http://localhost:8080`. Pengambilan status membutuhkan koneksi ke Minecraft-MP. Membuka `index.html` lewat `file://` tidak mendukung pembacaan JSON seperti hosting HTTP.

## Referensi

- [Minecraft-MP](https://minecraft-mp.com/server-s353692)
- [API resmi Minecraft-MP](https://minecraft-mp.com/help/api/) — API detail memerlukan key server; paket ini membaca halaman publik agar tidak memerlukan key.
- [GitHub Pages: custom workflows](https://docs.github.com/en/pages/getting-started-with-github-pages/using-custom-workflows-with-github-pages)
- [GitHub Actions: schedule](https://docs.github.com/en/actions/reference/workflows-and-actions/events-that-trigger-workflows#schedule)
- [Cloudflare Workers Cache API](https://developers.cloudflare.com/workers/runtime-apis/cache/)
