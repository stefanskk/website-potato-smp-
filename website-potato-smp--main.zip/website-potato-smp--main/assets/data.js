/* Konten Potato SMP. Harga dan aturan dipertahankan dari website yang diunggah. */
window.POTATO_DATA = {
  "ranks": [
    {
      "name": "Silver",
      "prices": {
        "1 Bulan": 5000,
        "3 Bulan": 7000,
        "1 Tahun": 10000,
        "Permanen": 15000
      },
      "benefits": [
        "Prefix Silver di chat & nametag",
        "Bonus SetHome",
        "Bonus Player Vault",
        "Bonus Block Limit"
      ]
    },
    {
      "name": "Golden",
      "prices": {
        "1 Bulan": 8000,
        "3 Bulan": 13000,
        "1 Tahun": 15000,
        "Permanen": 18000
      },
      "benefits": [
        "Prefix Golden di chat & nametag",
        "SetHome lebih banyak",
        "Player Vault tambahan",
        "Block Limit lebih besar",
        "Bonus reward rank"
      ]
    },
    {
      "name": "Elite",
      "prices": {
        "1 Bulan": 19000,
        "3 Bulan": 24000,
        "1 Tahun": 28000,
        "Permanen": 35000
      },
      "benefits": [
        "Prefix Elite di chat & nametag",
        "SetHome lebih banyak",
        "Player Vault tambahan",
        "Block Limit lebih besar",
        "Fitur kosmetik tambahan"
      ]
    },
    {
      "name": "Legend",
      "prices": {
        "1 Bulan": 32000,
        "3 Bulan": 38000,
        "1 Tahun": 44000,
        "Permanen": 55000
      },
      "benefits": [
        "Prefix Legend di chat & nametag",
        "SetHome lebih banyak",
        "Player Vault tambahan",
        "Block Limit lebih besar",
        "Pilihan chat & kosmetik lebih banyak"
      ]
    },
    {
      "name": "Slayer",
      "prices": {
        "1 Bulan": 45000,
        "3 Bulan": 57000,
        "1 Tahun": 70000,
        "Permanen": 85000
      },
      "benefits": [
        "Prefix Slayer di chat & nametag",
        "SetHome lebih banyak",
        "Player Vault tambahan",
        "Block Limit lebih besar",
        "Akses fitur rank tingkat lanjut"
      ]
    },
    {
      "name": "Frozen",
      "prices": {
        "1 Bulan": 75000,
        "3 Bulan": 100000,
        "1 Tahun": 125000,
        "Permanen": 142000
      },
      "benefits": [
        "Prefix Frozen di chat & nametag",
        "SetHome lebih banyak",
        "Player Vault tambahan",
        "Block Limit lebih besar",
        "Fitur rank tingkat lanjut",
        "Kosmetik eksklusif"
      ]
    },
    {
      "name": "Mythic",
      "prices": {
        "1 Bulan": 100000,
        "3 Bulan": 135000,
        "1 Tahun": 160000,
        "Permanen": 190000
      },
      "benefits": [
        "Prefix Mythic di chat & nametag",
        "SetHome lebih banyak",
        "Player Vault tambahan",
        "Block Limit lebih besar",
        "Fitur rank tingkat lanjut",
        "Benefit premium tambahan"
      ]
    },
    {
      "name": "Immortal",
      "prices": {
        "1 Bulan": 135000,
        "3 Bulan": 173000,
        "1 Tahun": 225000,
        "Permanen": 252000
      },
      "benefits": [
        "Prefix Immortal di chat & nametag",
        "SetHome lebih banyak",
        "Player Vault tambahan",
        "Block Limit lebih besar",
        "Fitur rank tingkat lanjut",
        "Benefit premium tambahan",
        "Kosmetik eksklusif"
      ]
    },
    {
      "name": "Celestial",
      "prices": {
        "1 Bulan": 180000,
        "3 Bulan": 240000,
        "1 Tahun": 270000,
        "Permanen": 300000
      },
      "benefits": [
        "Prefix Celestial di chat & nametag",
        "SetHome lebih banyak",
        "Player Vault tambahan",
        "Block Limit lebih besar",
        "Fitur rank tingkat lanjut",
        "Benefit premium lebih lengkap",
        "Kosmetik eksklusif"
      ]
    },
    {
      "name": "Lunarlight",
      "prices": {
        "1 Bulan": 275000,
        "3 Bulan": 302000,
        "1 Tahun": 370000,
        "Permanen": 425000
      },
      "benefits": [
        "Prefix Lunarlight di chat & nametag",
        "SetHome lebih banyak",
        "Player Vault tambahan",
        "Block Limit paling besar",
        "Akses benefit rank premium",
        "Paket benefit premium terlengkap",
        "Kosmetik eksklusif Lunarlight",
        "Prioritas benefit & layanan rank"
      ]
    }
  ],
  "rules": [
    {
      "title": "Sopan & Menghargai Player",
      "text": "Dilarang menghina, merendahkan, atau membuat player lain tidak nyaman.",
      "sanction": "Teguran → Mute → Kick sesuai kondisi.",
      "level": "light"
    },
    {
      "title": "Provokasi Ringan",
      "text": "Dilarang sengaja memancing keributan atau konflik kecil antar-player.",
      "sanction": "Teguran → Mute → Kick jika diulangi.",
      "level": "light"
    },
    {
      "title": "Bahasa Tidak Pantas",
      "text": "Dilarang menggunakan bahasa yang tidak pantas dan mengganggu kenyamanan komunitas.",
      "sanction": "Teguran → Mute sesuai tingkat pelanggaran.",
      "level": "light"
    },
    {
      "title": "Mengabaikan Arahan Staff",
      "text": "Mengabaikan arahan staff secara ringan dapat dianggap sebagai pelanggaran jika dilakukan berulang.",
      "sanction": "Teguran → Mute/Kick jika tetap mengulang.",
      "level": "light"
    },
    {
      "title": "Bullying",
      "text": "Dilarang melakukan perundungan atau sengaja menargetkan player untuk membuat mereka tidak nyaman.",
      "sanction": "Mute → Kick → Ban sementara.",
      "level": "medium"
    },
    {
      "title": "Pelecehan Verbal",
      "text": "Dilarang melakukan penghinaan atau pelecehan verbal terhadap player lain.",
      "sanction": "Mute → Ban sementara sesuai tingkat dan riwayat.",
      "level": "medium"
    },
    {
      "title": "Rasisme & Diskriminasi",
      "text": "Dilarang menyerang, menghina, atau memperlakukan seseorang secara tidak adil berdasarkan ras, warna kulit, asal, atau karakteristik kelompok lainnya.",
      "sanction": "Mute → Kick → Ban sementara; dapat ditingkatkan untuk kasus berat.",
      "level": "medium"
    },
    {
      "title": "Ujaran Kebencian",
      "text": "Dilarang menggunakan perkataan yang menyerang atau merendahkan kelompok tertentu.",
      "sanction": "Ban sementara atau hukuman lebih berat sesuai tingkat pelanggaran.",
      "level": "medium"
    },
    {
      "title": "Ancaman",
      "text": "Dilarang mengancam player lain atau menggunakan ancaman untuk menakut-nakuti dan memaksa.",
      "sanction": "Ban sementara atau lebih berat berdasarkan tingkat ancaman.",
      "level": "medium"
    },
    {
      "title": "Penipuan Transaksi",
      "text": "Dilarang sengaja menipu player dalam transaksi atau pertukaran item.",
      "sanction": "Pengembalian/reset keuntungan → Ban sementara sesuai kasus.",
      "level": "medium"
    },
    {
      "title": "Griefing",
      "text": "Dilarang sengaja merusak bangunan atau mengganggu area player lain.",
      "sanction": "Pemulihan/Rollback → Ban sementara sesuai kerugian.",
      "level": "medium"
    },
    {
      "title": "Promosi Tanpa Izin",
      "text": "Dilarang mempromosikan server, layanan, link, atau komunitas lain tanpa izin staff.",
      "sanction": "Hapus pesan → Mute → Ban sementara jika berat/berulang.",
      "level": "medium"
    },
    {
      "title": "Pornografi & Konten Seksual",
      "text": "Dilarang membagikan, meminta, menjual, atau mengarahkan player ke pornografi atau konten seksual.",
      "sanction": "Ban berat hingga permanen sesuai tingkat pelanggaran.",
      "level": "heavy"
    },
    {
      "title": "Pelecehan Seksual",
      "text": "Dilarang melakukan pelecehan seksual, komentar seksual yang tidak diinginkan, atau perilaku seksual yang membuat orang lain tidak nyaman.",
      "sanction": "Ban berat hingga permanen sesuai bukti dan tingkat pelanggaran.",
      "level": "heavy"
    },
    {
      "title": "Perilaku Seksual terhadap Anak",
      "text": "Dilarang melakukan grooming, mengajak perilaku seksual, atau mengeksploitasi pemain yang masih di bawah umur.",
      "sanction": "Ban permanen dan tindakan lanjutan sesuai kebijakan yang berlaku.",
      "level": "heavy"
    },
    {
      "title": "Doxxing & Penyebaran Data Pribadi",
      "text": "Dilarang menyebarkan alamat, nomor telepon, identitas, akun, atau informasi pribadi seseorang tanpa izin.",
      "sanction": "Ban berat/permanen dan tindakan lanjutan sesuai kebijakan server.",
      "level": "heavy"
    },
    {
      "title": "Cheat & Hack Client",
      "text": "Dilarang menggunakan cheat, hack client, exploit, atau modifikasi yang memberikan keuntungan tidak adil.",
      "sanction": "Ban sementara berat hingga ban permanen.",
      "level": "heavy"
    },
    {
      "title": "Eksploitasi Bug Besar",
      "text": "Dilarang memanfaatkan bug untuk mendapatkan keuntungan besar, terutama jika bug sengaja disembunyikan dari staff.",
      "sanction": "Reset/Rollback → Ban sementara atau permanen sesuai dampak.",
      "level": "heavy"
    },
    {
      "title": "Duplikasi & Manipulasi Ekonomi",
      "text": "Dilarang melakukan duplikasi item, manipulasi uang, atau eksploitasi ekonomi dalam skala besar.",
      "sanction": "Reset ekonomi/item → Ban berat hingga permanen.",
      "level": "heavy"
    },
    {
      "title": "Menyamar sebagai Staff",
      "text": "Dilarang mengaku sebagai Owner, Admin, Moderator, Helper, atau staff untuk menipu atau mengambil keuntungan.",
      "sanction": "Ban sementara berat hingga permanen sesuai dampak.",
      "level": "heavy"
    },
    {
      "title": "Mencoba Merusak Server",
      "text": "Dilarang melakukan serangan, mencoba mengambil akses tanpa izin, atau sengaja mengganggu layanan server.",
      "sanction": "Ban permanen dan tindakan lanjutan sesuai kebijakan server.",
      "level": "heavy"
    },
    {
      "title": "Menghindari Hukuman",
      "text": "Dilarang sengaja membuat atau menggunakan akun alternatif untuk menghindari hukuman yang sedang berlaku.",
      "sanction": "Hukuman dapat diperpanjang atau ditingkatkan sesuai kasus.",
      "level": "heavy"
    },
    {
      "title": "Ancaman Serius",
      "text": "Dilarang membuat ancaman serius terhadap keselamatan atau keamanan seseorang.",
      "sanction": "Ban berat/permanen dan tindakan lanjutan sesuai kebijakan.",
      "level": "heavy"
    },
    {
      "title": "Pelanggaran Berat Berulang",
      "text": "Melakukan pelanggaran berat berulang setelah menerima hukuman dapat menyebabkan sanksi maksimal.",
      "sanction": "Ban permanen sesuai bukti dan riwayat pelanggaran.",
      "level": "heavy"
    }
  ],
  "faqs": [
    {
      "category": "server",
      "question": "Apa IP server Potato SMP?",
      "answer": "Gunakan potatosmp.fun sebagai alamat server."
    },
    {
      "category": "server",
      "question": "Berapa port Bedrock?",
      "answer": "Port Bedrock adalah 19132."
    },
    {
      "category": "server",
      "question": "Bisa bermain dari Java dan Bedrock?",
      "answer": "Bisa. Potato SMP menyediakan koneksi untuk Java dan Bedrock."
    },
    {
      "category": "server",
      "question": "Versi Minecraft apa yang digunakan?",
      "answer": "Informasi koneksi pada website mencantumkan Java 1.20+ dan Bedrock 1.21+. Cek pengumuman komunitas jika ada pembaruan versi."
    },
    {
      "category": "server",
      "question": "Bagaimana menyalin IP dan port?",
      "answer": "Buka halaman Server, lalu gunakan tombol Salin di samping IP atau port yang diperlukan."
    },
    {
      "category": "server",
      "question": "Dari mana jumlah player online berasal?",
      "answer": "Jumlah player mengikuti data Minecraft-MP untuk Potato SMP. Waktu pengambilan data ditampilkan dan data lama ditandai. Pembaruan dari sumber bisa tertunda, sehingga jumlahnya dapat berbeda dari keadaan server saat ini."
    },
    {
      "category": "server",
      "question": "Kenapa informasi player online tidak tampil?",
      "answer": "Data Minecraft-MP mungkin belum tersedia atau koneksi sedang terganggu. Coba perbarui data atau buka tautan Minecraft-MP untuk memeriksa langsung."
    },
    {
      "category": "server",
      "question": "Apa yang perlu dicek sebelum masuk server?",
      "answer": "Pastikan platform dan versi Minecraft sesuai, gunakan IP potatosmp.fun, dan isi port 19132 jika bermain di Bedrock."
    },
    {
      "category": "profile",
      "question": "Apa fungsi Profil player?",
      "answer": "Profil player menyimpan nickname, platform, dan versi Minecraft di browser agar data pesanan rank bisa diisi lebih cepat."
    },
    {
      "category": "profile",
      "question": "Apakah Profil player adalah login Minecraft?",
      "answer": "Bukan. Profil ini adalah data lokal di browser, bukan autentikasi atau akun Minecraft resmi. Kamu tidak perlu memasukkan password Minecraft."
    },
    {
      "category": "profile",
      "question": "Apa yang harus diisi pada profil?",
      "answer": "Isi nickname sesuai nama di server, pilih Java atau Bedrock, lalu masukkan versi Minecraft yang kamu gunakan."
    },
    {
      "category": "profile",
      "question": "Apakah profil tersimpan setelah refresh?",
      "answer": "Ya, jika penyimpanan browser tersedia. Profil tersimpan di browser dan perangkat yang digunakan; menghapus data browser dapat menghapus profil."
    },
    {
      "category": "profile",
      "question": "Apakah perlu profil untuk melihat Store dan Vote?",
      "answer": "Tidak. Informasi Store dan Vote bisa dibaca langsung. Profil diperlukan saat menyiapkan pesanan rank agar identitas player tercantum."
    },
    {
      "category": "profile",
      "question": "Bagaimana mengganti nickname atau menghapus profil?",
      "answer": "Buka Profil player untuk mengubah data lalu simpan kembali. Gunakan Hapus profil jika ingin menghapus data yang tersimpan di browser."
    },
    {
      "category": "profile",
      "question": "Apakah profil sama di semua perangkat?",
      "answer": "Tidak. Profil tersimpan secara lokal di browser yang kamu gunakan dan tidak disinkronkan antarperangkat."
    },
    {
      "category": "profile",
      "question": "Apakah data profil dikirim otomatis?",
      "answer": "Data profil disimpan di browser. Saat membuka pesanan WhatsApp, identitas yang kamu isi dimasukkan ke teks pesanan; kamu tetap meninjau dan mengirim pesan sendiri."
    },
    {
      "category": "rank",
      "question": "Apa itu Rank?",
      "answer": "Rank adalah pilihan paket benefit tambahan. Kamu tetap bisa bermain tanpa membeli rank."
    },
    {
      "category": "rank",
      "question": "Di mana melihat harga dan benefit Rank?",
      "answer": "Buka Rank & Store, lalu lihat kartu rank yang ingin kamu pilih. Harga berbeda sesuai rank dan durasinya."
    },
    {
      "category": "rank",
      "question": "Apa saja durasi Rank yang tersedia?",
      "answer": "Tersedia 1 Bulan, 3 Bulan, 1 Tahun, dan Permanen. Harga untuk setiap durasi tercantum di Store."
    },
    {
      "category": "rank",
      "question": "Bagaimana memesan Rank?",
      "answer": "Pilih rank dari Store, lengkapi Profil player bila diperlukan, pilih durasi, lalu buka pesanan WhatsApp untuk meninjau dan mengirim pesan ke admin."
    },
    {
      "category": "rank",
      "question": "Apakah identitas harus diisi lagi setiap memesan?",
      "answer": "Jika profil sudah tersimpan, nickname, platform, dan versi digunakan untuk menyiapkan pesanan. Periksa kembali agar sesuai dengan player penerima rank."
    },
    {
      "category": "rank",
      "question": "Apakah benefit Rank bisa berubah?",
      "answer": "Benefit mengikuti informasi Store dan ketentuan server. Konfirmasikan detail benefit kepada admin saat memesan."
    },
    {
      "category": "rank",
      "question": "Apa itu Rank Voter?",
      "answer": "Rank gratis dari program Vote. Informasi reward menampilkan 20K Money, 1× Key Vote, serta Rank Voter + Fly 3 Jam."
    },
    {
      "category": "rank",
      "question": "Apa itu Rank Media?",
      "answer": "Rank gratis untuk kreator yang memenuhi ketentuan promosi Potato SMP di TikTok dan lolos verifikasi staff."
    },
    {
      "category": "rank",
      "question": "Apa syarat Rank Media?",
      "answer": "Upload minimal 2 video promosi Potato SMP di TikTok. Setiap video minimal 20–50 Like dan 800–2K View sesuai ketentuan program. Hubungi staff untuk verifikasi."
    },
    {
      "category": "rank",
      "question": "Apa benefit dan masa aktif Rank Media?",
      "answer": "Informasi program mencantumkan benefit 1M serta /nick, /fly, /anvil, dan /skull. Masa aktif 1 tahun 6 bulan (18 bulan) sejak rank diberikan, lalu rank dapat kedaluwarsa."
    },
    {
      "category": "vote",
      "question": "Apa itu Vote?",
      "answer": "Vote adalah cara mendukung Potato SMP melalui halaman voting Minecraft-MP."
    },
    {
      "category": "vote",
      "question": "Apa reward Vote?",
      "answer": "Informasi reward menampilkan 20K Money, 1× Key Vote, serta Rank Voter + Fly 3 Jam. Reward mengikuti ketentuan server."
    },
    {
      "category": "vote",
      "question": "Bagaimana format nickname untuk Vote?",
      "answer": "Gunakan nickname persis seperti di server. Java menggunakan nama biasa; Bedrock menyertakan titik di depan nama, misalnya .NamaPlayer."
    },
    {
      "category": "vote",
      "question": "Apakah nickname otomatis terisi di Minecraft-MP?",
      "answer": "Tidak. Website membuka halaman voting eksternal. Salin atau ketik ulang nickname yang tepat pada form Minecraft-MP, termasuk titik di depan nama Bedrock."
    },
    {
      "category": "vote",
      "question": "Apakah perlu Profil player sebelum Vote?",
      "answer": "Tidak. Halaman Vote dan tautan Minecraft-MP dapat dibuka tanpa menyimpan profil."
    },
    {
      "category": "vote",
      "question": "Bagaimana mendapatkan reward setelah Vote?",
      "answer": "Selesaikan proses voting di Minecraft-MP, lalu ikuti mekanisme reward yang berlaku di server. Jika reward belum masuk, periksa nickname yang digunakan dan hubungi staff."
    },
    {
      "category": "vote",
      "question": "Apakah halaman voting dibuka di tab baru?",
      "answer": "Tautan voting membuka situs Minecraft-MP di tab baru, sesuai pengaturan browser yang kamu gunakan."
    },
    {
      "category": "gameplay",
      "question": "Apa itu Mining?",
      "answer": "Mining adalah aktivitas menambang resource. Gunakan /warp mining untuk menuju areanya."
    },
    {
      "category": "gameplay",
      "question": "Apa itu Farming?",
      "answer": "Farming adalah aktivitas bercocok tanam. Gunakan /warp farm untuk menuju areanya."
    },
    {
      "category": "gameplay",
      "question": "Apa itu PvP Arena dan CPvP?",
      "answer": "Keduanya adalah aktivitas pertarungan yang tercantum pada informasi server. Untuk PvP Arena, gunakan /warp pvp."
    },
    {
      "category": "gameplay",
      "question": "Apa itu AFK Zone?",
      "answer": "Area untuk aktivitas AFK. Gunakan /warp afk untuk menuju area tersebut."
    },
    {
      "category": "gameplay",
      "question": "Bagaimana melindungi bangunan?",
      "answer": "Pelajari sistem Claim agar areamu terlindungi. Gunakan /rp help untuk melihat bantuan RedProtect di server."
    },
    {
      "category": "gameplay",
      "question": "Apa itu SetHome?",
      "answer": "SetHome adalah fitur menyimpan lokasi rumah. Bonus jumlah SetHome tercantum pada benefit rank."
    },
    {
      "category": "gameplay",
      "question": "Apa itu Block Limit?",
      "answer": "Block Limit adalah batas blok yang tercantum pada benefit rank. Konfirmasikan rincian batas kepada staff jika diperlukan."
    },
    {
      "category": "gameplay",
      "question": "Apa itu Economy?",
      "answer": "Economy merupakan sistem uang dalam game yang menjadi bagian dari konsep Survival Economy Potato SMP."
    },
    {
      "category": "gameplay",
      "question": "Bagaimana mulai Survival?",
      "answer": "Masuk ke server, kenali peraturan, lalu gunakan /rtp untuk menjelajahi dunia Survival. Pelajari Claim sebelum membangun."
    },
    {
      "category": "gameplay",
      "question": "Apa itu Player Vault?",
      "answer": "Player Vault adalah penyimpanan tambahan yang tercantum pada benefit rank."
    },
    {
      "category": "guide",
      "question": "Bagaimana player baru mulai?",
      "answer": "Tentukan Java atau Bedrock, cek versi, lalu tambahkan potatosmp.fun. Gunakan port 19132 untuk Bedrock. Setelah masuk, baca aturan dan mulai kenali Survival, Economy, serta Claim."
    },
    {
      "category": "guide",
      "question": "Di mana melihat panduan koneksi?",
      "answer": "Buka halaman Panduan atau Server untuk melihat langkah koneksi dan tombol Salin IP."
    },
    {
      "category": "guide",
      "question": "Apakah player baru harus membeli Rank?",
      "answer": "Tidak. Rank adalah pilihan tambahan bagi player, bukan syarat untuk mulai bermain."
    },
    {
      "category": "guide",
      "question": "Kalau masih bingung harus menghubungi siapa?",
      "answer": "Buka halaman Komunitas untuk bergabung ke kanal resmi dan mencari bantuan staff."
    },
    {
      "category": "order",
      "question": "Apa itu Order WhatsApp?",
      "answer": "Fitur untuk menyiapkan pesan pesanan rank ke WhatsApp admin. Pesan belum dikirim sampai kamu menekan Kirim di WhatsApp."
    },
    {
      "category": "order",
      "question": "Apa saja isi pesan pesanan?",
      "answer": "Pesan berisi nickname, platform, versi Minecraft, rank, durasi, dan harga sesuai pilihanmu."
    },
    {
      "category": "order",
      "question": "Mengapa pesanan memerlukan Profil player?",
      "answer": "Profil membantu menyiapkan identitas penerima rank. Pastikan nickname dan platform sudah benar sebelum mengirim pesanan."
    },
    {
      "category": "order",
      "question": "Apakah pesan pesanan bisa diedit?",
      "answer": "Bisa. Pesan disiapkan sebagai teks WhatsApp sehingga dapat diperiksa dan diubah sebelum dikirim."
    },
    {
      "category": "order",
      "question": "Apakah pembayaran dilakukan di website?",
      "answer": "Tidak. Website menyiapkan pesan pesanan. Konfirmasikan pembayaran dan pemberian rank langsung dengan admin melalui WhatsApp."
    },
    {
      "category": "order",
      "question": "Mengapa WhatsApp tidak terbuka?",
      "answer": "Pastikan koneksi internet dan WhatsApp tersedia. Periksa pengaturan browser jika tautan atau tab baru diblokir."
    },
    {
      "category": "order",
      "question": "Siapa yang menerima pesan pesanan?",
      "answer": "Pesanan diarahkan ke WhatsApp admin Potato SMP yang tercantum pada tombol pesanan website."
    },
    {
      "category": "website",
      "question": "Bagaimana membuka halaman lain?",
      "answer": "Gunakan navigasi utama. Di layar kecil, buka tombol Menu untuk melihat semua halaman."
    },
    {
      "category": "website",
      "question": "Bagaimana kembali ke Beranda?",
      "answer": "Tekan logo Potato SMP atau pilih Beranda pada navigasi."
    },
    {
      "category": "website",
      "question": "Apakah website bisa digunakan di HP?",
      "answer": "Ya. Tata letak menyesuaikan layar HP dan desktop; tombol utama dapat digunakan dengan sentuhan."
    },
    {
      "category": "website",
      "question": "Apakah halaman hilang setelah refresh?",
      "answer": "Halaman mengikuti alamat hash pada browser. Profil tetap tersimpan jika penyimpanan browser tersedia."
    },
    {
      "category": "website",
      "question": "Mengapa animasi tidak bergerak?",
      "answer": "Animasi mengikuti preferensi pengurangan gerakan pada perangkat atau browser. Fitur utama tetap dapat digunakan."
    },
    {
      "category": "website",
      "question": "Bagaimana mencari jawaban di FAQ?",
      "answer": "Gunakan pencarian dan kategori FAQ untuk mempersempit pertanyaan yang ingin kamu baca."
    }
  ],
  "modes": [
    {
      "name": "Mining",
      "description": "Isi tasmu dengan hasil tambang. Mulai dari satu blok, pulang bawa banyak resource.",
      "command": "/warp mining",
      "icon": "pickaxe"
    },
    {
      "name": "Farming",
      "description": "Tanam, rawat, lalu panen. Nikmati waktu santai di area farming.",
      "command": "/warp farm",
      "icon": "leaf"
    },
    {
      "name": "PvP Arena",
      "description": "Uji kemampuan bertarungmu di arena PvP. Siapkan perlengkapan terbaikmu.",
      "command": "/warp pvp",
      "icon": "swords"
    },
    {
      "name": "CPvP",
      "description": "Pilihan aktivitas pertarungan untuk kamu yang suka tantangan.",
      "command": "",
      "icon": "gem"
    },
    {
      "name": "AFK Zone",
      "description": "Tempat beristirahat sejenak saat kamu sedang AFK.",
      "command": "/warp afk",
      "icon": "moon"
    },
    {
      "name": "Claim",
      "description": "Lindungi area bangunanmu. Pelajari cara claim sebelum mulai membangun.",
      "command": "/rp help",
      "icon": "shield"
    },
    {
      "name": "Economy",
      "description": "Kumpulkan uang dalam game dan kenali sistem ekonomi Potato SMP.",
      "command": "",
      "icon": "coin"
    },
    {
      "name": "Survival",
      "description": "Jelajah dunia, kumpulkan resource, dan bangun tempat yang bisa kamu sebut rumah.",
      "command": "/rtp",
      "icon": "home"
    }
  ],
  "freeRanks": [
    {
      "name": "Voter",
      "requirements": [
        "Lakukan vote melalui halaman voting Potato SMP di Minecraft-MP.",
        "Masukkan nickname persis seperti di server. Untuk Bedrock, sertakan titik di depan nama."
      ],
      "benefits": [
        "Rank Voter",
        "20K Money",
        "1× Key Vote",
        "Fly 3 jam"
      ]
    },
    {
      "name": "Media",
      "requirements": [
        "Buat dan upload minimal 2 video promosi Potato SMP di TikTok.",
        "Setiap video minimal 20–50 Like dan 800–2K View sesuai ketentuan program.",
        "Pengajuan perlu diverifikasi oleh staff."
      ],
      "benefits": [
        "Benefit 1M sesuai program Media",
        "/nick — ganti nametag",
        "/fly — bisa terbang",
        "/anvil — buka menu anvil",
        "/skull — mengambil skin kepala player",
        "Masa aktif 1 tahun 6 bulan (18 bulan) sejak rank diberikan. Setelah itu rank dapat kedaluwarsa."
      ]
    }
  ]
};
