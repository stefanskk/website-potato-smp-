/* Konfigurasi publik. Jangan menaruh API key atau password di file ini. */
window.POTATO_CONFIG = Object.freeze({
  statusUrl: './status.json', // Untuk Worker opsional, ganti dengan URL HTTPS /status.json.
  statusRefreshMs: 60000,
  statusStaleMs: 10 * 60 * 1000,
  adminWhatsApp: '6285137375162'
});
