# Potato SMP — Potato Club

Tema baru krem, oranye, kuning, dan hijau lembut. Maskot dan animasi dibuat dengan CSS; tidak membutuhkan library animasi atau font eksternal.

## Cara pasang di GitHub Pages

1. Ekstrak ZIP dan upload **seluruh isi folder** `website-potato-smp--main` ke root repository website. Jangan hanya mengganti `index.html`.
2. Ikutkan `assets`, `scripts`, dan **`.github/workflows`**. Folder `.github` dapat tersembunyi di pengelola file Android.
3. Untuk jumlah pemain otomatis, buka **Settings → Pages → Source → GitHub Actions**.
4. Buka **Actions → Potato SMP Pages + Player Status → Run workflow** di branch utama. Tunggu proses berhasil.
5. Buka website. Jika tema lama masih muncul, hapus cache situs atau buka tab privat.

Petunjuk lengkap dan opsi Cloudflare Worker: **STATUS-SETUP.md**. Domain pada `CNAME` tetap `mc.potatosmp.fun`. Website belum diterbitkan dari percakapan ini.

## Perubahan

- Susunan beranda dan seluruh tema dibangun ulang; detail tetap ada di halaman terpisah.
- Kentang melambai dan berkedip, kentang kecil melompat, daun bergoyang, balok dan ikon melayang, serta bintang berputar. Tombol dan kartu merespons sentuhan/hover.
- Tombol jeda animasi di footer, dukungan reduced motion, dan jeda saat tab tidak aktif.
- Navigasi HP, tombol salin, pencarian FAQ, filter aturan, pilihan durasi rank, dan pratinjau pesan order.
- Live chat beserta koneksi, API key, dan endpoint lamanya dihapus dari paket baru.
- Jumlah pemain hanya berasal dari halaman Minecraft-MP yang diminta, dengan waktu dan penanda data lama/gagal.
- Harga, benefit, aturan, versi Minecraft, tautan komunitas, dan nomor admin mengikuti ZIP asli.

## Status jumlah pemain

Workflow mengambil halaman Minecraft-MP di sisi server, lalu menerbitkan `status.json` bersama website. Jadwal sekitar **5 menit**, dapat tertunda oleh antrean GitHub. Browser membaca hasil setiap **60 detik** ketika Beranda/Server aktif.

Data lebih dari **10 menit** ditandai **Data lama**, dengan angka diberi label **terakhir**. Gagal mengambil data tidak dianggap server offline. Tombol Perbarui membaca hasil terbaru yang sudah diterbitkan; tidak memaksa workflow berjalan.

Snapshot dalam ZIP bukan angka yang terus diperbarui. Aktifkan workflow atau endpoint Worker agar datanya diperbarui. Membuka `index.html` melalui `file://` tidak mendukung status JSON; gunakan hosting HTTP/HTTPS.

## Profil, vote, dan order

Profil hanya disimpan di browser, bukan autentikasi Minecraft; tidak ada password. Nama Bedrock boleh memiliki awalan titik. Tombol salin nama vote menambahkan satu titik pada nama Bedrock bila belum ada. Tempel nama yang disalin di halaman vote; website tidak mengisi formulir Minecraft-MP secara otomatis.

Order menyiapkan pesan WhatsApp berisi nickname, platform, versi, rank, durasi, dan harga. Pembayaran dan pemberian rank dilakukan oleh admin setelah dikonfirmasi. Website tidak mengirim pesan atau melakukan pembayaran otomatis.

## Konfigurasi

| File | Isi |
|---|---|
| `index.html` | Susunan halaman dan tautan komunitas |
| `assets/style.css` | Tema, tata letak, animasi |
| `assets/data.js` | Harga, benefit, aturan, FAQ, gamemode |
| `assets/config.js` | Nomor WhatsApp publik dan endpoint status |
| `assets/logo.jpeg` | Logo asli |
| `CNAME` | Domain website |

Tidak perlu `npm install` untuk menerbitkan website statis.

## Hasil pemeriksaan

- **14 tes simulasi DOM lokal lulus**: 11 rute, semua 40 kombinasi harga rank, pesan WhatsApp, profil, nama Bedrock, clipboard gagal, FAQ, 24 aturan, status gagal/kedaluwarsa, tombol jeda, tautan/file lokal, dan penghapusan chat.
- **8 tes parser/sumber lulus**. Jalankan ulang dengan `node --test scripts/status-source.test.mjs`.
- Pengambilan angka asli dari halaman Minecraft-MP berhasil saat penyusunan paket.
- Sintaks JavaScript dan target elemen diperiksa.
- **Tampilan belum diuji langsung di browser desktop/HP**: pemeriksaan izin otomatis menolak akses browser pengujian ke alamat lokal. Layout responsif telah dibuat; cek tampilannya setelah dipasang.
- Deployment GitHub/Worker dan pengiriman pesan WhatsApp belum dijalankan. Undangan komunitas memakai alamat asli dan dapat kedaluwarsa di layanan masing-masing.

Ketersediaan status tetap bergantung pada Minecraft-MP. Perubahan format halaman sumber dapat memerlukan penyesuaian parser. Tidak ada jaminan mutlak bebas bug di semua perangkat.
