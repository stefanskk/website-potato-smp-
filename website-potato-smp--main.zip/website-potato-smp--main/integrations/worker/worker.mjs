import { fetchStatus, unknownStatus } from '../../scripts/status-source.mjs';

function responseFor(data, status = 200, ttl = 180) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      'Content-Type': 'application/json; charset=utf-8',
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, OPTIONS',
      'Cache-Control': `public, max-age=${ttl}`,
      'X-Content-Type-Options': 'nosniff',
    },
  });
}

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    if (url.pathname !== '/' && url.pathname !== '/status.json') {
      return responseFor({ error: 'Not found' }, 404, 0);
    }
    if (request.method === 'OPTIONS') {
      return new Response(null, { status: 204, headers: {
        'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Methods': 'GET, OPTIONS',
        'Access-Control-Max-Age': '86400',
      } });
    }
    if (request.method !== 'GET') return responseFor({ error: 'Method not allowed' }, 405, 0);
    // Fixed cache key ignores cache-busting query strings; this is not an open proxy.
    const cacheKey = new Request(`${url.origin}/status.json`);
    const cached = await caches.default.match(cacheKey);
    if (cached) return cached;
    let response;
    try {
      response = responseFor(await fetchStatus());
    } catch {
      // Cache failures briefly to protect the source during an outage.
      response = responseFor(unknownStatus('Minecraft-MP belum dapat dibaca. Cek halaman sumber.'), 200, 30);
    }
    ctx.waitUntil(caches.default.put(cacheKey, response.clone()));
    return response;
  },
};
