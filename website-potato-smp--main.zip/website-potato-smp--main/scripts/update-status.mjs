import { writeFile, rename } from 'node:fs/promises';
import { resolve } from 'node:path';
import { fetchStatus, unknownStatus } from './status-source.mjs';

const destination = resolve(process.argv[2] || 'status.json');
let status;
try {
  status = await fetchStatus();
  console.log(`Minecraft-MP: ${status.status}; pemain ${status.playersOnline ?? '?'}/${status.playersMax ?? '?'}.`);
} catch (error) {
  // Publish an honest unknown state instead of old data or a false offline count.
  status = unknownStatus('Minecraft-MP belum dapat dibaca. Cek halaman sumber.');
  console.warn(`Status belum tersedia: ${error.message}`);
}
await writeFile(`${destination}.tmp`, `${JSON.stringify(status, null, 2)}\n`, 'utf8');
await rename(`${destination}.tmp`, destination);
