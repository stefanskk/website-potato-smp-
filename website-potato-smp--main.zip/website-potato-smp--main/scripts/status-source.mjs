// Single source of truth for the GitHub updater and optional Cloudflare Worker.
export const SOURCE = 'https://minecraft-mp.com/server-s353692';

function textOf(html) {
  return html.replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi, '')
    .replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi, '')
    .replace(/<[^>]*>/g, ' ')
    .replace(/&(?:nbsp|#160|#xA0);/gi, ' ')
    .replace(/&amp;/g, '&').replace(/\s+/g, ' ').trim();
}

function rowValues(html) {
  const rows = new Map();
  for (const row of html.matchAll(/<tr\b[^>]*>([\s\S]*?)<\/tr>/gi)) {
    const cells = [...row[1].matchAll(/<t[dh]\b[^>]*>([\s\S]*?)<\/t[dh]>/gi)];
    if (cells.length >= 2) rows.set(textOf(cells[0][1]).toLowerCase(), textOf(cells[1][1]));
  }
  return rows;
}

export function unknownStatus(error = 'Sumber belum dapat dibaca.', attemptedAt = new Date().toISOString()) {
  return { source: SOURCE, status: 'unknown', playersOnline: null, playersMax: null,
    checkedAt: null, attemptedAt, error };
}

export function parseStatus(html, checkedAt = new Date().toISOString()) {
  if (typeof html !== 'string' || html.length > 1_000_000 || !Number.isFinite(Date.parse(checkedAt))) {
    throw new Error('Respons atau waktu sumber tidak valid.');
  }
  // Reject login pages, bot challenges and unrelated server listings.
  if (!/<title\b[^>]*>[^<]*#353692\b[^<]*<\/title>/i.test(html)
      && !/<link\b[^>]*href=["']https:\/\/minecraft-mp\.com\/server-s353692\/?["']/i.test(html)) {
    throw new Error('Identitas halaman sumber tidak cocok.');
  }
  const rows = rowValues(html);
  const statusText = rows.get('server status') || '';
  const matchStatus = /^(Online|Offline)\b/i.exec(statusText);
  if (!matchStatus) throw new Error('Status server tidak ditemukan di sumber.');
  const status = matchStatus[1].toLowerCase();
  const players = /^([\d,]+)\s*\/\s*([\d,]+)$/.exec(rows.get('players') || '');
  if (!players && status === 'online') throw new Error('Jumlah pemain tidak ditemukan di sumber.');
  const playersOnline = players ? Number(players[1].replace(/,/g, '')) : null;
  const playersMax = players ? Number(players[2].replace(/,/g, '')) : null;
  if (players && (!Number.isSafeInteger(playersOnline) || !Number.isSafeInteger(playersMax)
      || playersOnline < 0 || playersMax < 0 || playersOnline > 1_000_000 || playersMax > 100_000_000)) {
    throw new Error('Jumlah pemain dari sumber tidak valid.');
  }
  const sourceCheckedText = statusText.replace(/^(Online|Offline)\s*/i, '').trim() || null;
  const age = /\bChecked\s+(\d+)\s+(second|minute|hour|day|week)s?\s+ago\b/i.exec(sourceCheckedText || '');
  const unitSeconds = { second: 1, minute: 60, hour: 3600, day: 86400, week: 604800 };
  const sourceAgeSeconds = age ? Number(age[1]) * unitSeconds[age[2].toLowerCase()] : null;
  const sourceCheckedAt = sourceAgeSeconds === null ? null
    : new Date(Date.parse(checkedAt) - sourceAgeSeconds * 1000).toISOString();
  return { source: SOURCE, status, playersOnline, playersMax, checkedAt,
    sourceCheckedText, sourceCheckedAt };
}

export async function fetchStatus(fetcher = fetch) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 15_000);
  try {
    const response = await fetcher(SOURCE, {
      headers: { Accept: 'text/html', 'User-Agent': 'PotatoSMP-Status/1.0 (+https://mc.potatosmp.fun)' },
      redirect: 'error', signal: controller.signal,
    });
    if (!response.ok) throw new Error(`Sumber mengembalikan HTTP ${response.status}.`);
    const contentType = response.headers.get('content-type') || '';
    if (!contentType.includes('text/html')) throw new Error('Tipe respons sumber tidak sesuai.');
    const html = await response.text();
    return parseStatus(html, new Date().toISOString());
  } finally {
    clearTimeout(timeout);
  }
}
