import { test } from 'node:test';
import assert from 'node:assert/strict';
import { SOURCE, parseStatus, unknownStatus, fetchStatus } from './status-source.mjs';

const time = '2026-09-16T08:00:00.000Z';
const page = (status = 'Online', players = '32/2026', checked = 'Checked 1 minute ago') => `
<!doctype html><title>Potato SMP | Minecraft Server #353692</title>
<link rel="canonical" href="${SOURCE}"><table>
<tr><td><i></i><strong>Server Status</strong></td><td><span>${status}</span><small>${checked}</small></td></tr>
<tr><td><i></i><strong>Players</strong></td><td><strong>${players}</strong></td></tr></table>`;

test('reads actual table layout and preserves source check time', () => {
  assert.deepEqual(parseStatus(page(), time), { source: SOURCE, status: 'online', playersOnline: 32,
    playersMax: 2026, checkedAt: time, sourceCheckedText: 'Checked 1 minute ago',
    sourceCheckedAt: '2026-09-16T07:59:00.000Z' });
});
test('zero players is online when the source says online', () => {
  const result = parseStatus(page('Online', '0 / 2,026'), time);
  assert.equal(result.status, 'online');
  assert.equal(result.playersOnline, 0);
  assert.equal(result.playersMax, 2026);
});
test('offline comes only from explicit source state, with no invented player zero', () => {
  const result = parseStatus(page('Offline', 'N/A'), time);
  assert.equal(result.status, 'offline');
  assert.equal(result.playersOnline, null);
});
test('old source checks keep their age even when recently fetched', () => {
  const result = parseStatus(page('Online', '3/20', 'Checked 2 days ago'), time);
  assert.equal(result.sourceCheckedAt, '2026-09-14T08:00:00.000Z');
});
test('malformed count, unknown state, unrelated pages and challenges are rejected', () => {
  for (const html of [page('Online', '--'), page('Checking', '3/20'),
    page().replaceAll('353692', '999999'), '<title>Just a moment...</title>']) {
    assert.throws(() => parseStatus(html, time));
  }
});
test('unknown status does not claim offline, zero players or a successful check', () => {
  const result = unknownStatus('Unavailable', time);
  assert.equal(result.status, 'unknown');
  assert.equal(result.playersOnline, null);
  assert.equal(result.checkedAt, null);
  assert.equal(result.attemptedAt, time);
});
test('HTTP and content type failures are rejected before parsing', async () => {
  await assert.rejects(fetchStatus(async () => new Response('blocked', { status: 403 })));
  await assert.rejects(fetchStatus(async () => new Response('{}', { headers: { 'content-type': 'application/json' } })));
});
test('fetch uses fixed source and parses a valid response', async () => {
  const result = await fetchStatus(async (url) => {
    assert.equal(url, SOURCE);
    return new Response(page(), { headers: { 'content-type': 'text/html; charset=UTF-8' } });
  });
  assert.equal(result.playersOnline, 32);
  assert.ok(Number.isFinite(Date.parse(result.checkedAt)));
});
